//
//  Shona_AppTests.swift
//  Shona AppTests
//
//  Created by Munashe T Chitima on 6/7/2025.
//

import Testing

struct Shona_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
